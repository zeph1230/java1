package exam01;

public class Exam03 {
	
	int num1 = 1;
	int num2;
	int resultNum;
	
	public void function() {
		
	}
	public static void main(String[] args) {
		
		int num1 = 10;
		int num2 = 2;
		int resultNum = num1 + num2;
		System.out.println(resultNum);
		resultNum = num1 - num2;
		System.out.println(resultNum);
		resultNum = num1 * num2;
		System.out.println(resultNum);
		resultNum = num1 / num2;
		System.out.println(resultNum);
		System.out.println(1 + 1 + " = �����");
		
		
	}
	

}
