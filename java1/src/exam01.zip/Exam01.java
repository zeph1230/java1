package exam01;

public class Exam01 {

	public static void main(String[] args) {		
		int num1=2;
		int num2=3;
		System.out.println(num1+num2);
		System.out.println("�ڹ��ڹ�!");
		
		int resultNum = num1 + num2;
		System.out.println("��°� = " + resultNum);
		System.out.println("5" + "5");
		
		short s1 = 1;
		byte b1 = 1;
		int i1 = 1;
		long l1 = 1;
		String str = "��";
		char c1 = 'a';
		float f1 = 1.23f;
		double d1 = 1.23;
		boolean bl1 = true;
		boolean bl2 = false;
		
		
	}
	
}
