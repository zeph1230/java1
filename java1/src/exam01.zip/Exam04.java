package exam01;

public class Exam04 {

	public static void main(String[] args) {
		
		int num1 = 4;
		if(num1==3) {
			System.out.println("��");
		}else if(num1==4){
			System.out.println("4����");
		}else {
			System.out.println("3�� 4�� �ƴ�");
			
		}
		System.out.println("????");
		
	}
}
