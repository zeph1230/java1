package exam01;

public class Exam02 {

	public static void main(String[] args) {
	
		int num1 = 1;
		int num2 = 1;
		System.out.println(num1==num2);
		System.out.println(num1!=num2);
		System.out.println(num1>num2);
		System.out.println(num1<num2);
		System.out.println(num1>=num2);
		System.out.println(num1<=num2);
		
		boolean isSame = num1==num2;
		System.out.println(isSame);
	}
}
