package exam04;

public class Student extends Person {

	
	public void doWork() {
		System.out.println("���θ� �մϴ�");
	}
	public static void main(String[] args) {
		
	}
}
