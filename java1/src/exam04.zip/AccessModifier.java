package exam04;

public class AccessModifier {
	
	public static void main(String[] args) {
		Modifier e = new Modifier();
		e.pubNum = 3;
//		e.priNum = 3;
		e.defNum = 3;
		e.proNum = 3;
	}

}
